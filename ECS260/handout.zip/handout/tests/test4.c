//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { unsigned long arr[3]={1,2,3}; printf("arr[1] = %lu", arr[1]); return 0;}