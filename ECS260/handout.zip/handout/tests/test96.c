//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { double arr[3][3]={1,2,3,1,2,3,1,2,3}; printf("arr[3][3] = %lf", arr[3][3]); return 0;}