//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { unsigned int arr[3][3]={1,2,3,1,2,3,1,2,3}; printf("arr[1][-1] = %u", arr[1][-1]); return 0;}