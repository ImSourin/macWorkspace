//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { int a=1, b=2, c=3;int* arr[3][3]={&a, &b, &c,&a, &b, &c,&a, &b, &c}; printf("arr[3][1] = %d", *arr[3][1]); return 0;}