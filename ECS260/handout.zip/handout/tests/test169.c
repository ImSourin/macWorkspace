//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan
#include<stdio.h>

struct st{
    int a;
};

int main() {
    struct st arr[3];
    arr[0].a = 1;
    arr[1].a = 2;
    arr[2].a = 3;
    printf("arr[1] = %d", arr[1].a);
    return 0;
}