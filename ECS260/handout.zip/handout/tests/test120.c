//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { char arr[3][3]={1,2,3,1,2,3,1,2,3}; printf("arr[-1][1] = %c", arr[-1][1]); return 0;}