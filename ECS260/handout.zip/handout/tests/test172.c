//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan
#include<stdio.h>

struct st{
    int a[3];
};

int main() {
    struct st arr[3];
    arr[0].a[0] = 1;
    arr[0].a[1] = 2;
    arr[0].a[2] = 3;
    arr[1] = arr[0];
    arr[2] = arr[0];
    printf("arr[1][1] = %d", arr[1].a[1]);
    return 0;
}