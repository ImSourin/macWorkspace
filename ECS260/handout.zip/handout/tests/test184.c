//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan
#include<stdio.h>

int main() {
    int *arr[1][1];
    *arr[-1][0] = 30;
    return 0;
}