//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { float arr[3][3]={1,2,3,1,2,3,1,2,3}; printf("arr[1][3] = %f", arr[1][3]); return 0;}