//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { char arr[3]={1,2,3}; printf("arr[3] = %c", arr[3]); return 0;}