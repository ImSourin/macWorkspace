//Teammates: Sourin Chakrabarti, Ujwal Pratap Krishna Koluvakolanu Thyagarajan 
#include<stdio.h>
int main() { double arr[3][3]={1,2,3,1,2,3,1,2,3}; printf("arr[-1][1] = %lf", arr[-1][1]); return 0;}