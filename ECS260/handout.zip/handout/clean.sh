#!/bin/bash

test_dir="./tests"

rm -f *.so *.os *.bc
rm -f $test_dir/*.bc
